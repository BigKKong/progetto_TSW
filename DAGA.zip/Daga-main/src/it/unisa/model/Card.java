package it.unisa.model;

public class Card {
private String numero;
private String data;
private int cvc;
public String getNumero() {
	return numero;
}
public void setNumero(String numero) {
	this.numero = numero;
}
public String getData() {
	return data;
}
public void setData(String data) {
	this.data = data;
}
public int getCvc() {
	return cvc;
}
public void setCvc(int cvc) {
	this.cvc = cvc;
}
}
